function place()
  local objectString = "castleswitch:6:4:castleswitch:14:4:royalchest:102:4:castlehiddentrapdoor:198:9:castlehiddentrapdoor:198:12:castlehiddentrapdoor:6:212:castlehiddentrapdoor:6:215:castleswitch:1:217:castleswitch:12:217:"
  return objectString
end